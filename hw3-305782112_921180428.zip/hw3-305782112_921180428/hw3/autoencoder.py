import torch
import torch.nn as nn
import torch.nn.functional as F
#import normal distribution
from torch.distributions import normal

class EncoderCNN(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()

        modules = []

        # TODO: Implement a CNN. Save the layers in the modules list.
        # The input shape is an image batch: (N, in_channels, H_in, W_in).
        # The output shape should be (N, out_channels, H_out, W_out).
        # You can assume H_in, W_in >= 64.
        # Architecture is up to you, but you should use at least 3 Conv layers.
        # You can use any Conv layer parameters, use pooling or only strides,
        # use any activation functions, use BN or Dropout, etc.
        # ====== YOUR CODE: ======
        #pool = 0
        #pool_every=2
        
        #try also padding=1, stride=2, kernel=4 and filters=in_channels*2,4,6,...
        #num_filters=5
        #k_size=5
        #p=0
        #s=1
        num_filters=4
        k_size=4
        p=1
        s=2
        step=(out_channels-in_channels)//num_filters
        filters=[0]*num_filters
        for i in range(num_filters):
            filters[i]=in_channels+step*i
        self.filters=filters
        modules.append(nn.Conv2d(in_channels, filters[0], kernel_size=k_size, padding=p,stride=s))
        modules.append(nn.BatchNorm2d(filters[0]))
        l=len(filters)
        for i in range(l - 1):
            modules.append(nn.ReLU())
            #if pool == pool_every - 1:
            #    modules.append(nn.MaxPool2d(kernel_size=2, stride=2))
            #    pool = 0
            #else:
            #    pool += 1
            modules.append(nn.Conv2d(filters[i], filters[i + 1], padding=p, kernel_size=k_size,stride=s))
            modules.append(nn.BatchNorm2d(filters[i + 1]))
            
            modules.append(nn.ReLU())
            modules.append(nn.Conv2d(filters[i+1], filters[i + 1], padding=1, kernel_size=3,stride=1))
            #modules.append(nn.BatchNorm2d(filters[i + 1]))
            
        modules.append(nn.ReLU())
        #if pool == pool_every - 1:
        #    modules.append(nn.MaxPool2d(kernel_size=2, stride=2))
        
        modules.append(nn.Conv2d(filters[i+1], out_channels , padding=p, kernel_size=k_size, stride=s))

        # ========================
        self.cnn = nn.Sequential(*modules)

    def forward(self, x):
        return self.cnn(x)


class DecoderCNN(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()

        modules = []

        # TODO: Implement the "mirror" CNN of the encoder.
        # For example, instead of Conv layers use transposed convolutions,
        # instead of pooling do unpooling (if relevant) and so on.
        # You should have the same number of layers as in the Encoder,
        # and they should produce the same volumes, just in reverse order.
        # Output should be a batch of images, with same dimensions as the
        # inputs to the Encoder were.
        # ====== YOUR CODE: ======
        #pool_every=2
        #num_filters=5
        #k_size=5
        #p=0
        #s=1
        num_filters=4
        k_size=4
        p=1
        s=2
        step=(out_channels-in_channels)//num_filters
        filters=[0]*num_filters
        l=num_filters
        for i in range(num_filters):
            filters[i]=in_channels+step*i
        #pool=l % pool_every -1
        #filters=[1024,683,343]
        modules.append(nn.ReLU())
        modules.append(nn.ConvTranspose2d(in_channels, filters[0], padding=p, kernel_size=k_size, stride=s))
        for i in range(l-1):
            modules.append(nn.ReLU())
            modules.append(nn.ConvTranspose2d(filters[i], filters[i+1], padding=p, kernel_size=k_size,stride=s))
            modules.append(nn.BatchNorm2d(filters[i+1]))
            #if pool==0:
            #    modules.append(nn.MaxUnpool2d(kernel_size=2, stride=2))
            #    pool=pool_every-1
            #else:
            #    pool-=1
            modules.append(nn.ReLU())
            modules.append(nn.ConvTranspose2d(filters[i+1], filters[i+1], padding=1, kernel_size=3,stride=1))
            #modules.append(nn.BatchNorm2d(filters[i+1]))
        
        modules.append(nn.ReLU())
        
        #if pool==0:
        #    modules.append(nn.MaxPool2d(kernel_size=2, stride=2))
        modules.append(nn.ConvTranspose2d(filters[l-1], out_channels, padding=p, kernel_size=k_size,stride=s))
        # ========================
        self.cnn = nn.Sequential(*modules)

    def forward(self, h):
        # Tanh to scale to [-1, 1] (same dynamic range as original images).
        return torch.tanh(self.cnn(h))



class VAE(nn.Module):
    def __init__(self, features_encoder, features_decoder, in_size, z_dim):
        """
        :param features_encoder: Instance of an encoder the extracts features
        from an input.
        :param features_decoder: Instance of a decoder that reconstructs an
        input from it's features.
        :param in_size: The size of one input (without batch dimension).
        :param z_dim: The latent space dimension.
        """
        super().__init__()
        self.features_encoder = features_encoder
        self.features_decoder = features_decoder
        self.z_dim = z_dim

        self.features_shape, n_features = self._check_features(in_size)
        #print(self.z_dim)
        #print(n_features)
        #print(self.features_shape[0])
        #print(self.features_shape[1])
        
        # TODO: Add parameters needed for encode() and decode().
        # ====== YOUR CODE: ======
        
        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self.at_mu, self.at_logvar = nn.Linear(n_features,self.z_dim), nn.Linear( n_features, self.z_dim)
        self.at_rec = nn.Linear(z_dim, n_features)
        
        
        #self.w=torch.ones(n_features, self.z_dim, device=self.device)
        #self.b=torch.rand(1,self.z_dim, device=self.device)
        #self.w_sigma=torch.zeros( n_features, self.z_dim, device=self.device)
        #self.b_sigma=torch.rand(1,self.z_dim, device=self.device)
        
        #if torch.cuda.is_available():
        #    self.w = self.w.cuda()
        #    self.w_sigma=self.w_sigma.cuda()
        
        # ========================

    def _check_features(self, in_size):
        device = next(self.parameters()).device
        with torch.no_grad():
            # Make sure encoder and decoder are compatible
            x = torch.randn(1, *in_size, device=device)
            h = self.features_encoder(x)
            xr = self.features_decoder(h)
            assert xr.shape == x.shape
            # Return the shape and number of encoded features
            return h.shape[1:], torch.numel(h)//h.shape[0]
        
    def encode(self, x):

        # TODO: Sample a latent vector z given an input x.
        # 1. Use the features extracted from the input to obtain mu and
        # log_sigma2 (mean and log variance) of the posterior p(z|x).
        # 2. Apply the reparametrization trick.
        # ====== YOUR CODE: ======
        h=self.features_encoder.forward(x)
        #print(h)
        #print(h.shape)
        h = h.view(h.size(0),-1)
        #print(h.shape)
        #print(self.w.shape)
        #mu=torch.mm(h,self.w)+self.b
        #log_sigma2=torch.mm(h,self.w_sigma)+self.b_sigma
        mu, log_sigma2 = self.at_mu(h), self.at_logvar(h)
        std = log_sigma2.mul(0.5).exp_()
        #print(mu)
        #print(log_sigma2)
        
        u=torch.randn(1,device=self.device)
        #print(u)
        #m = normal.Normal(torch.tensor([0.0], device=self.device), torch.tensor([1.0], device=self.device))
        #u=m.sample()
        #print(u)
        z=mu+u*std
        # ========================

        return z, mu, log_sigma2

    def decode(self, z):
        # TODO: Convert a latent vector back into a reconstructed input.
        # 1. Convert latent to features.
        # 2. Apply features decoder.
        # ====== YOUR CODE: ======
        #h=torch.mm(self.w,torch.transpose(z,1,0))
        h=self.at_rec(z)
        h=h.view(-1,self.features_shape[0],self.features_shape[1],self.features_shape[1])
        x_rec=self.features_decoder.forward(h)
        # ========================

        # Scale to [-1, 1] (same dynamic range as original images).
        return torch.tanh(x_rec)

    def sample(self, n):
        samples = []
        device = next(self.parameters()).device
        with torch.no_grad():
            # TODO: Sample from the model.
            # Generate n latent space samples and return their reconstructions.
            # Remember that for the model, this is like inference.
            # ====== YOUR CODE: ======
            
            for i in range(n):
                #u=self.mu+self.sigma*torch.randn(self.z_dim,device=self.device)
                u=torch.randn(self.z_dim,device=self.device)
                new_x=self.decode(u)
                #print(new_x)
                samples.append(new_x.view(new_x.shape[1],new_x.shape[2],new_x.shape[3]).cpu())
                
            # ========================
        return samples

    def forward(self, x):
        z, mu, log_sigma2 = self.encode(x)
        return self.decode(z), mu, log_sigma2


def vae_loss(x, xr, z_mu, z_log_sigma2, x_sigma2):
    """
    Pointwise loss function of a VAE with latent space of dimension z_dim.
    :param x: Input image batch of shape (N,C,H,W).
    :param xr: Reconstructed (output) image batch.
    :param z_mu: Posterior mean (batch) of shape (N, z_dim).
    :param z_log_sigma2: Posterior log-variance (batch) of shape (N, z_dim).
    :param x_sigma2: Likelihood variance (scalar).
    :return:
        - The VAE loss
        - The data loss term
        - The KL divergence loss term
    all three are scalars, averaged over the batch dimension.
    """
    loss, data_loss, kldiv_loss = None, None, None
    # TODO: Implement the VAE pointwise loss calculation.
    # Remember that the covariance matrix of the posterior is diagonal.
    # ====== YOUR CODE: ======    
   
    data_loss=torch.mean((x-xr)**2)/x_sigma2
   

    #print(z_log_sig)    
    z_dim=z_mu.shape[1]
    #have a look on this !!
    sigma = torch.exp(z_log_sigma2)
    norm2_mu=torch.sum(z_mu**2,dim=1)
    tr = torch.sum(sigma, dim=1)
    log_det = torch.sum(z_log_sigma2, dim=1)
    kldiv_loss = tr + norm2_mu - z_dim - log_det
    kldiv_loss=torch.mean(kldiv_loss)/z_dim
    #kldiv_loss=torch.mean(z_mu**2) + torch.mean(sigma) - z_dim - torch.mean(log_sigma)
    #print(kldiv_loss)
    loss=data_loss+kldiv_loss 
    
    # ========================

    return loss, data_loss, kldiv_loss
