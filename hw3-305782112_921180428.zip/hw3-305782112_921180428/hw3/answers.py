r"""
Use this module to write your answers to the questions in the notebook.

Note: Inside the answer strings you can use Markdown format and also LaTeX
math (delimited with $$).
"""

# ==============
# Part 1 answers


def part1_generation_params():
    start_seq = ""
    temperature = .0001
    # TODO: Tweak the parameters to generate a literary masterpiece.
    # ====== YOUR CODE: ======
    start_seq, temperature = 'Once upon a time,', 0.7
    # ========================
    return start_seq, temperature


part1_q1 = r"""

our goal is to predict the next character of given char string.
thus, we need to train it with sequences of characters that labeled with th following char.
"""

part1_q2 = r"""
thanks to the hidden layer in the GRU implementation. the hidden layer pass information from the past for
the prediction of the next char. 

"""

part1_q3 = r"""
we want to predict the next in the right context, for that reason we need to train in the right context (meaning 
in the right order). for example, let's examine a conversation between two characters in the play: the first character
says "good morning" and of course the second will answer "good morning". if we will shuffle the sentences, our
model will miss a trivial correlation as described. 
"""

part1_q4 = r"""
when the temperature is high, and generating the text, we can see that the characters are very random (and get more random
as a function of increasing the temperature), it's happen because high temperature make the next char probability to 
be uniform over all the the characters.
when the temperature is high, and generating the text, we end with the same couple of words over and over.
it's happen because low temperature make the next char probability to be 1 for the highest probability character 
(as we getting closer for 0).
and that's the reason when we training we want to keep a neutral temperature - because we want all the options.
but when generating text we wnt to be close as possible to the origin so we lower the temperature.
"""
# ==============


# ==============
# Part 2 answers

PART2_CUSTOM_DATA_URL = None


def part2_vae_hyperparams():
    hypers = dict(
        batch_size=0,
        h_dim=0, z_dim=0, x_sigma2=0,
        learn_rate=0.0, betas=(0.0, 0.0),
    )
    # TODO: Tweak the hyperparameters to generate a former president.
    # ====== YOUR CODE: ======
    hypers['batch_size']=32 #100
    hypers['h_dim']=1024 #500 #1024
    hypers['z_dim']=16 #16#128 #2
    hypers['x_sigma2']=20 #10 #1  #5
    hypers['learn_rate']=0.0002 #0.0001 #0.001
    hypers['betas']=(0.9, 0.999) #0.5,0.999
    
    # ========================
    return hypers


part2_q1 = r"""
**Your answer:**
The loss function in the VAE is composed of 2 parts: KL divergence and data loss. The second one is the loss that we usually use and that represents the loss between the input and the output, while the KL divergence guarantees the probability assumptions. The parameter $\sigma^2$ is important because it decides how to balance this 2 quantities and how much importance to give to each one of them. With a low variance, we give more importance to the data loss term and so it is harder to sample. On the other hand, if the variance is too large we can have very high loss between the input and output that means a lot of differences between the input image and the reconstructed image. 
"""
# ==============

# ==============
# Part 3 answers

PART3_CUSTOM_DATA_URL = None


def part3_gan_hyperparams():
    hypers = dict(
        batch_size=32, z_dim=128,
        data_label=1, label_noise=0.3,
        discriminator_optimizer=dict(
            type='Adam',  # Any name in nn.optim like SGD, Adam
            weight_decay=0.001,
            betas=(0.5,0.999),
            lr=0.0002,
        ),
        generator_optimizer=dict(
            type='Adam',  # Any name in nn.optim like SGD, Adam
            weight_decay=0.001,
            betas=(0.5,0.999),
            lr=0.0002,
        ),
    )

    return hypers

part3_q1 = r"""
**Your answer:**

We have to maintain the gradient when we are sampling in the batch training function. Indeed, when we are training, we want to optimize the result of the generator and thus we need the gradient in order to do it. In the other moments, we don't maintain the gradient in order to not change his value for the training.
"""

part3_q2 = r"""
**Your answer:**
The loss of the generator is connected to the discriminator loss. This is the reason why we cannot focus just on the generator loss and stop when it is below a certain threshold. It can happen that, even if the generator loss is very low, the discriminator finds new differences between the fake images and the real ones  in the next batch and this will bring the generator loss up again. In this case, we should not stop just because of the low generator loss.

If the loss of the discriminator is constant, while the loss of the generator decreases, it means that the generator is learning faster than the discriminator. To balance things, one can train the discriminator more than the generator.

"""

part3_q3 = r"""
**Your answer:**
The GAN is divided in two parts that compete against each other. The generator tries to construct a realistic image, while the discriminator tries to find out if the image is real or not. This permits a better training in order to obtain images that are more similar to the specific real ones that come from the training set. For this reason, the results of the GAN are better overall images in terms of the background for example. The goal is to reconstruct images that look as similar as possible to the dataset.
On the other hand, the VAE aims to sample images from the label space, that is to reconstruct images from a prior distribution. We assume that the instances can be reconstruct from a latent space with smaller dimension and we want to learn through the VAE the main characteristics of the images in the dataset. Thus, even if the pictures are blurry, it captures the main characteristics of a face in each sample.

"""

# ==============


